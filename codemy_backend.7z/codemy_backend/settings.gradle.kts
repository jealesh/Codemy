rootProject.name = "ktor-sample"

dependencyResolutionManagement {
    repositories {
        mavenCentral()
    }
}

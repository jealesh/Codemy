package com.example

import io.ktor.server.application.*
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.server.routing.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.plugins.cors.routing.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class RegisterRequest(
    val fullName: String,
    val username: String,
    val age: Int,
    val email: String,
    val password: String
)

@Serializable
data class RegisterResponse(
    val message: String,
    val userId: Long? = null
)

fun main() {
    embeddedServer(Netty, port = 8080, host = "0.0.0.0") {
        module()
    }.start(wait = true)
}

fun Application.module() {
    DatabaseFactory.connect()  // подключаемся к БД

    install(ContentNegotiation) {
        json(Json {
            ignoreUnknownKeys = true
            prettyPrint = true
        })
    }

    install(CORS) {
        anyHost()
        allowMethod(HttpMethod.Options)
        allowMethod(HttpMethod.Get)
        allowMethod(HttpMethod.Post)
        allowHeader(HttpHeaders.ContentType)
        allowHeader(HttpHeaders.Authorization)
        allowCredentials = true
    }

    routing {
        get("/") {
            call.respondText("Server Codemy is working!")
        }

        post("/register") {
            try {
                val request = call.receive<RegisterRequest>()
                println("Registration received: $request")

                // здесь потом будет сохранение в БД
                call.respond(
                    HttpStatusCode.Created,
                    RegisterResponse("User successfully created", userId = 1L)
                )
            } catch (e: Exception) {
                println("Registration Error: ${e.message}")
                call.respond(
                    HttpStatusCode.BadRequest,
                    RegisterResponse("Error: ${e.message}")
                )
            }
        }
    }
}